import numpy as np
from scipy.linalg import block_diag
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from scipy.linalg import expm
import random2


#np.set_printoptions(precision=4,suppress=True)

nrows = 16
ncols = 4
Lines_1 = np.zeros((nrows, ncols))


#Importing the experimental energy values
file = open(r"Exp_2qubit_ground_energy_values.txt")
i=0
for line in file.readlines():
    Lines_1[i,0] = float(line)
    i = i+1

file = open(r"Exp_2qubit_1excited_energy_values.txt")
i=0
for line in file.readlines():
    Lines_1[i,1] = float(line)
    i = i+1

file = open(r"Exp_2qubit_2excited_energy_values.txt")
i=0
for line in file.readlines():
    Lines_1[i,2] = float(line)
    i = i+1

file = open(r"Exp_2qubit_3excited_energy_values.txt")
i=0
for line in file.readlines():
    Lines_1[i,3] = float(line)
    i = i+1

R = []
file = open(r"Radius_values.txt")
i=0
for line in file.readlines():
    R.append(float(line))
    i = i+1





#Importing the Experimental energy errors
y_error_0 = []
file = open(r"Exp_2qubit_ground_energy_errors.txt")
i=0
for line in file.readlines():
    y_error_0.append(float(line))
    i = i+1

y_error_1 = []
file = open(r"Exp_2qubit_1excited_energy_errors.txt")
i=0
for line in file.readlines():
    y_error_1.append(float(line))
    i = i+1

y_error_2 = []
file = open(r"Exp_2qubit_2excited_energy_errors.txt")
i=0
for line in file.readlines():
    y_error_2.append(float(line))
    i = i+1

y_error_3 = []
file = open(r"Exp_2qubit_3excited_energy_errors.txt")
i=0
for line in file.readlines():
    y_error_3.append(float(line))
    i = i+1


#Plotting the VQE Energies
plt.errorbar(R, Lines_1[:,0],y_error_0, fmt='.',label='Ground state Energies')
plt.errorbar(R, Lines_1[:,1],y_error_1, fmt='.',label='1st excited state Energies')
plt.errorbar(R, Lines_1[:,2],y_error_2, fmt='.',label='2nd excited state Energies')
plt.errorbar(R, Lines_1[:,3],y_error_3, fmt='.',label='3rd excited state Energies')



file = open(r"complete_theoretical_energy.dat")
nrows = 100         #Defined as steps in the google colab file
ncols = 5
Lines_2 = np.zeros((nrows, ncols))
i=0
for line in file.readlines():
    a = line.split()
    l = a[0:5]
    l = [float(j) for j in l]
    Lines_2[i] = l
    i = i+1
R_new = np.linspace(0.2, 1.9, 100)


#Plotting the Theoretical Energies
plt.plot(R_new, Lines_2[:,1], 'k', lw = 0.6)
plt.plot(R_new, Lines_2[:,2], 'k', lw = 0.6)
plt.plot(R_new, Lines_2[:,3], 'k', lw = 0.6)
plt.plot(R_new, Lines_2[:,4], 'k', lw = 0.6)
plt.xlabel('Internuclear distance ($A^{\circ}$)')
plt.ylabel('Energy (Ha)')
#plt.legend()
plt.xlim(0.2, 1.9)
plt.ylim(-1.25, 1)
plt.show()