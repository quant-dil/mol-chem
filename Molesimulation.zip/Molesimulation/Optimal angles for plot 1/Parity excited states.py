import numpy as np
from scipy.linalg import block_diag
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from scipy.linalg import expm



#np.set_printoptions(precision=4,suppress=True)



file = open(r"Parity coefficients.txt")
nrows = 16
ncols = 6
Lines = np.zeros((nrows, ncols))
i=0
for line in file.readlines():
    a = line.split()
    l = a[0:6]
    l = [float(j) for j in l]
    Lines[i] = l
    i = i+1




# Pauli matrices
I  = np.array([[ 1, 0],
               [ 0, 1]])
Sx = np.array([[ 0, 1],
               [ 1, 0]])
Sy = np.array([[ 0,-1j],
               [1j, 0]])
Sz = np.array([[ 1, 0],
               [ 0,-1]])

# Hadamard matrix
H = (1/np.sqrt(2))*np.array([[ 1, 1],
                             [ 1,-1]])

# Phase matrix
S = np.array([[ 1, 0],
              [ 0,1j]])

# single qubit basis states |0> and |1>
q0 = np.array([[1],
               [0]])
q1 = np.array([[0],
               [1]])

# Projection matrices |0><0| and |1><1|
P0  = np.dot(q0,q0.conj().T)
P1  = np.dot(q1,q1.conj().T)


# Rotation matrices as a function of theta, e.g. Rx(theta), etc.
Rx = lambda theta : np.array([[    np.cos(theta/2),-1j*np.sin(theta/2)],
                              [-1j*np.sin(theta/2),    np.cos(theta/2)]])
Ry = lambda theta : np.array([[    np.cos(theta/2),   -np.sin(theta/2)],
                              [    np.sin(theta/2),    np.cos(theta/2)]])
Rz = lambda theta : np.array([[np.exp(-1j*theta/2),                0.0],
                              [                0.0, np.exp(1j*theta/2)]])

# CNOTij, where i is control qubit and j is target qubit
CNOT10 = np.kron(P0,I) + np.kron(P1,Sx) # control -> q1, target -> q0
CNOT01 = np.kron(I,P0) + np.kron(Sx,P1) # control -> q0, target -> q1

SWAP   = block_diag(1,Sx,1)



ansatz_a = lambda theta: expm(1j*theta*np.kron(Sx,Sy)) 

ansatz_b = lambda theta: expm(1j*0.5*theta*np.kron(Sx,Sy))        #Changing the ansatz circuit which is required to explore the perpendicular space

Ground_E = []
Excited_1 = []
Excited_2 = []
Excited_3 = []

Angles_0 =[]
Angles_1=[]
Angles_2=[]
Angles_3=[]
overlap_00=[]

R = Lines[:,0]

nuclear_repulsion = 0.7055696146



def projective_expected(theta,ansatz,psi0,beta,phi,Hmol):
    # this will depend on the hard-coded Hamiltonian + coefficients
    circuit = ansatz(theta[0])
    psi = np.dot(circuit,psi0)
    
    energy = np.dot(psi.conj().T, np.dot(Hmol, psi))[0,0]

    # summation over i beta_i*<|i><i|>
    for i in range (len(phi)):
        energy += beta[i]*np.dot(psi.conj().T,np.dot(np.dot(phi[i],phi[i].conj().T),psi))[0][0]

    return np.real(energy)

def Nuclear_Repulsion(r):
    return 1/(4*np.pi*8.854187817*1e-12) * (1.602176634*1e-19)**2/(r*1e-10) * 2.2937104486906 * 1e17

R = Lines[:,0]

Exact_E = np.zeros([len(R),4])

for i in range (0,len(R)):
    #Finding the exact energies for each R through diagonalization
    c0 = Lines[i,1]
    c1 = Lines[i,2]
    c2 = Lines[i,3]
    c3 = Lines[i,4]
    c4 = Lines[i,5]


    Hmol  =(c0*np.kron(I,I)
          + c2*np.kron(I,Sz)
          + c1*np.kron(Sz,I)
          + c3*np.kron(Sz,Sz)
          + c4*np.kron(Sx,Sx))
    
    NR = Nuclear_Repulsion(R[i])

    electronic_energies, eigen_vecs = np.linalg.eig(Hmol)
    idx = electronic_energies.argsort()[::]   
    electronic_energies = electronic_energies[idx]
    eigen_vecs = eigen_vecs[:,idx]

    v0 = eigen_vecs[:,0].reshape(4,1)
    v1 = eigen_vecs[:,3]
    v2 = eigen_vecs[:,1]
    v3 = eigen_vecs[:,2]

    Exact_E[i,:] = np.real(electronic_energies[0:4] + NR)
    #________________________________________________________________________________________________________________________




    #Finding the energies through VQE and VQD
    
    #Preparation of initial state i.e. the Hartree-Fock state |01>
    psi0 = np.zeros((4,1))
    psi0[0] = 1
    psi0 = np.dot(np.kron(I,Sx),psi0)


    #Ground state___________________________________________________
    phi = [psi0]
    theta  = [0.0]
    beta = [0]

    result = minimize(projective_expected,theta,args=(ansatz_a,psi0,beta,phi,Hmol), method = 'Nelder-Mead')
    theta  = result.x[0]
    val    = result.fun
    Energy0 = val + NR
    Ground_E.append(Energy0)
    Angles_0.append(theta)


    #Ground state  wavefunction from the above step
    circuit = ansatz_a(theta)
    phi0 = np.dot(circuit,psi0)

    overlap_00.append(np.abs(np.dot(v0.conj().T, phi0))[0,0])


    #Excited state 1__________________________________________________
    phi = [phi0]
    theta = [0.0]
    beta0 = 5
    beta = [beta0]

    result = minimize(projective_expected,theta,args=(ansatz_a,psi0,beta,phi,Hmol), method = 'Nelder-Mead')
    theta  = result.x[0]
    val    = result.fun
    Energy1 = val+NR
    Excited_1.append(Energy1)
    Angles_1.append(theta)

    #First excited state wavefunction from the above step
    circuit = ansatz_a(theta)
    phi1 = np.dot(circuit,psi0)




    #Changing the choice of the initial state to |00> as we want to explore the space spanned by {|00>, |11>}.
    psi0 = np.zeros((4,1))
    psi0[0] = 1


    #Excited state 2__________________________________________________
    phi = [phi0, phi1]
    theta  = [0.0]
    beta0 = 1
    beta1 = Energy1
    beta = [beta0, beta1]

    result = minimize(projective_expected,theta,args=(ansatz_b,psi0,beta,phi,Hmol), method = 'Nelder-Mead')
    theta  = result.x[0]
    val    = result.fun
    Energy2 = val+NR
    Excited_2.append(Energy2)
    Angles_2.append(theta)

    #Second excited state wavefunction from the above step
    circuit = ansatz_b(theta)
    phi2 = np.dot(circuit,psi0)



    #Excited state 3__________________________________________________
    phi = [phi0, phi1, phi2]
    theta  = [0.0]
    beta0 = 6
    beta1 = Energy1
    beta2 = 5
    beta = [beta0, beta1, beta2]

    result = minimize(projective_expected,theta,args=(ansatz_b,psi0,beta,phi,Hmol), method = 'Nelder-Mead')
    theta  = result.x[0]
    val    = result.fun
    Energy3 = val+NR
    Excited_3.append(Energy3)
    Angles_3.append(theta)

    #Second excited state wavefunction from the above step
    circuit = ansatz_b(theta)
    phi3 = np.dot(circuit,psi0)



'''
print (R)
print ('\n')
print (Ground_E)
print ('\n')
print (Angles_0)
print ('\n')
print (Excited_3)
print ('\n')
print (Angles_3)
'''

plt.plot(R, Exact_E[:,0],'bo', markersize=3, label='Exact')
#plt.plot(R, np.array(Ground_E), color='b')
plt.plot(R, np.array(Ground_E), 'b*', markersize=3, label = 'VQE_ground')

plt.plot(R, Exact_E[:,3],'yo', markersize=3)
#plt.plot(R, np.array(Ground_E), color='b')
plt.plot(R, np.array(Excited_1), 'y*', markersize=3, label = 'Exact_3rd')

plt.plot(R, Exact_E[:,1],'go', markersize=3)
#plt.plot(R, np.array(Ground_E), color='b')
plt.plot(R, np.array(Excited_2), 'g*', markersize=3, label = 'Exact_1st')

plt.plot(R, Exact_E[:,2],'ko', markersize=3)
#plt.plot(R, np.array(Ground_E), color='b')
plt.plot(R, np.array(Excited_3), 'k*', markersize=3, label = 'Exact_2nd')


'''
plt.plot(R, np.array(Excited_1),color='b')
plt.plot(R, np.array(Excited_1),'o',color='y', label = 'First excited state')

plt.plot(R, np.array(Excited_2),color='b')
plt.plot(R, np.array(Excited_2),'o',color='g', label = 'Second excited state')

plt.plot(R, np.array(Excited_3),color='b')
plt.plot(R, np.array(Excited_3),'o',color='m', label = 'Third excited state')
'''

plt.xlabel('R (A$^{\circ}$)')
plt.ylabel('Electronic Energy (Hartree)')
plt.legend()
plt.show()


plt.plot(R, overlap_00, label='Actual - VQE overlap')
plt.legend()
plt.show()



temp = np.zeros((len(R),5))
temp[:,0] = R
temp[:,1] = Angles_0
temp[:,2] = Angles_1
temp[:,3] = Angles_2
temp[:,4] = Angles_3



np.savetxt('Optimized_angles.dat', temp, delimiter='          ', fmt='%.15f')









print('')
print ('Testing the Hamiltonian eigen vectors at R = %f A' %(R[0]))
Rad = R[0]
nuclear_repulsion = 1/(4*np.pi*8.854187817*1e-12) * (1.602176634*1e-19)**2/(Rad*1e-10) * 2.2937104486906 * 1e17
c0 = Lines[0,1]
c1 = Lines[0,2]
c2 = Lines[0,3]
c3 = Lines[0,4]
c4 = Lines[0,5]

Hmol  =(c0*np.kron(I,I)
      + c2*np.kron(I,Sz)
      + c1*np.kron(Sz,I)
      + c3*np.kron(Sz,Sz)
      + c4*np.kron(Sx,Sx))

electronic_energies, eigen_vecs = np.linalg.eig(Hmol)
idx = electronic_energies.argsort()[::]   
electronic_energies = electronic_energies[idx]
eigen_vecs = eigen_vecs[:,idx]

for i in range (4):
    a = electronic_energies[i]
    print("Classical diagonalization: %f Eh"%(np.real(a) + nuclear_repulsion))




#______________Testing the UCC ansartz by actually plotting the energy and overlaps as a function of the theta parameter_______________________
psi0 = np.zeros((4,1))
psi0[0] = 1
psi0 = np.dot(np.kron(I,Sx),psi0)


circuit = ansatz_a(Angles_0[0])
phi0 = np.dot(circuit,psi0)

beta = [0]
phi = [psi0]
Param = np.linspace(-np.pi, np.pi, 1000)
Ground_E = []
overlap_01 = []
for i in Param:
    A=[i]
    Ground_E.append( projective_expected(A,ansatz_a,psi0,beta,phi,Hmol) + nuclear_repulsion)

    circuit = ansatz_a(A[0])
    phi1 = np.dot(circuit,psi0)

    overlap_01.append(np.abs(np.dot(phi0.conj().T, phi1)[0][0]))

plt.plot(Param, Ground_E)
plt.title('Energy vs parameter')
plt.show()

plt.plot(Param, overlap_01, label='Overlap wrt Ground State at R = %f A$^\circ$' %(R[0]))
plt.title('Overlap')
plt.legend()
plt.show()

print ('\n')
print ('The optimized theta for the ground state at R=%f is: %f' %(R[0],Angles_0[0]))


'''
print ('_________________________________________________________________________________________________________________')
print ('\n')
'''





'''
# initial basis, put in |01> state with Sx operator on q0
psi0 = np.zeros((4,1))
psi0[0] = 1
psi0 = np.dot(np.kron(I,Sx),psi0)


#Ground state___________________________________________________
phi = [psi0]
theta  = [0.0]
beta = [0]

result = minimize(projective_expected,theta,args=(ansatz,psi0,beta,phi,Hmol), method = 'Nelder-Mead')
theta  = result.x[0]
val    = result.fun
Energy0 = val+1/(4*np.pi*8.854187817*1e-12) * (1.602176634*1e-19)**2/(Rad*1e-10) * 2.2937104486906 * 1e17
Ground_E.append(Energy0)

#Ground state  wavefunction from the above step
circuit = ansatz(theta)
phi0 = np.dot(circuit,psi0)
'''



print ('_________________________________________________________________________________________________________________')
print ('\n')